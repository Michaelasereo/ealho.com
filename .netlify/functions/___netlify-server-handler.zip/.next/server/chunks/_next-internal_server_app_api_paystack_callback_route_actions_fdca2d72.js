module.exports=[75570,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paystack_callback_route_actions_fdca2d72.js.map