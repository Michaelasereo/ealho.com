module.exports=[29777,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_event-types_route_actions_8098a322.js.map