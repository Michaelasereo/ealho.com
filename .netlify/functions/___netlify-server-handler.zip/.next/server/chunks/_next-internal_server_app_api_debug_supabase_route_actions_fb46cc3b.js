module.exports=[72143,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_debug_supabase_route_actions_fb46cc3b.js.map