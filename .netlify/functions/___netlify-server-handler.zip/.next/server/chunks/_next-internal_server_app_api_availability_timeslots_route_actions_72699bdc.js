module.exports=[92380,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_availability_timeslots_route_actions_72699bdc.js.map