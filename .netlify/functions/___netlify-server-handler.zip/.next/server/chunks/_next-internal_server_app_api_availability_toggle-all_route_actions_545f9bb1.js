module.exports=[72548,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_availability_toggle-all_route_actions_545f9bb1.js.map