module.exports=[65925,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paystack_initialize_route_actions_34b3bcb1.js.map