module.exports=[9801,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_availability_out-of-office_route_actions_274a6763.js.map