module.exports=[26523,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_booking-history_route_actions_afe18d1a.js.map