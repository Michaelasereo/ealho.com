module.exports=[96536,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dietitians_route_actions_6187712e.js.map