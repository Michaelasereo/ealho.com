module.exports=[14898,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_clear-therapists_route_actions_eafec519.js.map