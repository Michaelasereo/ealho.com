module.exports=[94016,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_check-user_route_actions_85812c3d.js.map