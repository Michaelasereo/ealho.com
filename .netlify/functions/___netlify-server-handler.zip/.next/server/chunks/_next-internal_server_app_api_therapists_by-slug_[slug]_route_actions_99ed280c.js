module.exports=[18325,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_therapists_by-slug_%5Bslug%5D_route_actions_99ed280c.js.map