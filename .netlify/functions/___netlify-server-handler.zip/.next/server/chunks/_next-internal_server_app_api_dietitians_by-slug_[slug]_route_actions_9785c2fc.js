module.exports=[93900,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dietitians_by-slug_%5Bslug%5D_route_actions_9785c2fc.js.map