module.exports=[78707,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_stats_route_actions_18a773f6.js.map