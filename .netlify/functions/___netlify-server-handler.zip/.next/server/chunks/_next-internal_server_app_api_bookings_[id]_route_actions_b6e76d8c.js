module.exports=[81454,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bookings_%5Bid%5D_route_actions_b6e76d8c.js.map