module.exports=[28277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_approve-request_%5Bid%5D_route_actions_c6337a4f.js.map