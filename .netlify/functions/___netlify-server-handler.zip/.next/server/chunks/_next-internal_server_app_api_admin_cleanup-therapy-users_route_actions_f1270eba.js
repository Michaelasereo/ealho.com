module.exports=[28478,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_cleanup-therapy-users_route_actions_f1270eba.js.map