module.exports=[45929,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_dietitian_%5Bid%5D_route_actions_f3766279.js.map