module.exports=[68918,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_therapists_enroll_route_actions_1bd1d397.js.map