module.exports=[56317,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dietitians_%5Bid%5D_route_actions_9550c64c.js.map