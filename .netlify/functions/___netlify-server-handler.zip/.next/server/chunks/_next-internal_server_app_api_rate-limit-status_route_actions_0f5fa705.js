module.exports=[51480,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rate-limit-status_route_actions_0f5fa705.js.map