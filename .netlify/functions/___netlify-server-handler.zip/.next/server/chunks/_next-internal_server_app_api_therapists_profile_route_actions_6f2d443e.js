module.exports=[35699,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_therapists_profile_route_actions_6f2d443e.js.map