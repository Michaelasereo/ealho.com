module.exports=[20400,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_debug_unapprove-request_route_actions_fb8fff6c.js.map