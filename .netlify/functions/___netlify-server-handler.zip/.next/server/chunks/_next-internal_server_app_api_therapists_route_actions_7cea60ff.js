module.exports=[67732,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_therapists_route_actions_7cea60ff.js.map