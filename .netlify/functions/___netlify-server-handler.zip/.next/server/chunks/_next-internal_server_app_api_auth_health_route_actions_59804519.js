module.exports=[52992,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_health_route_actions_59804519.js.map