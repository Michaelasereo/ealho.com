module.exports=[9730,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_availability_route_actions_d5ea7375.js.map