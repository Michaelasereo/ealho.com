module.exports=[97804,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bookings_route_actions_eb288a0b.js.map