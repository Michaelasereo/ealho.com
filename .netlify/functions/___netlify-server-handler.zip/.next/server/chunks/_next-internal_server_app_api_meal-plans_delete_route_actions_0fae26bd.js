module.exports=[18348,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_meal-plans_delete_route_actions_0fae26bd.js.map