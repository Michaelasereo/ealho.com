module.exports=[88841,e=>{"use strict";async function t(e){let t=process.env.BREVO_API_KEY,o=process.env.BREVO_SENDER_EMAIL||"noreply@daiyet.co",r=process.env.BREVO_SENDER_NAME||"Daiyet";if(!t)return console.error("BREVO_API_KEY is not configured"),{success:!1,error:"Email service not configured"};if(!e.to||!e.subject)return{success:!1,error:"Missing required fields: to and subject are required"};if(!e.htmlContent&&!e.textContent)return{success:!1,error:"Either htmlContent or textContent must be provided"};try{let i=Array.isArray(e.to)?e.to.map(e=>({email:e})):[{email:e.to}],n={sender:{name:e.fromName||r,email:e.from||o},to:i,subject:e.subject,htmlContent:e.htmlContent||void 0,textContent:e.textContent||void 0};e.replyTo&&(n.replyTo={email:e.replyTo.email,name:e.replyTo.name}),e.attachments&&e.attachments.length>0&&(n.attachment=e.attachments),e.tags&&e.tags.length>0&&(n.tags=e.tags),e.params&&(n.params=e.params);let a=await fetch("https://api.brevo.com/v3/smtp/email",{method:"POST",headers:{"api-key":t,"Content-Type":"application/json"},body:JSON.stringify(n)});if(!a.ok){let e=await a.text(),t=`Brevo API error: ${a.status}`;try{let o=JSON.parse(e);t=o.message||o.error||t}catch{t=e||t}return console.error("Brevo API error:",{status:a.status,statusText:a.statusText,error:t}),{success:!1,error:t}}let s=await a.json();return console.log("Email sent successfully via Brevo:",{messageId:s.messageId,to:Array.isArray(e.to)?`${e.to.length} recipients`:e.to,subject:e.subject}),{success:!0,messageId:s.messageId}}catch(t){let e=t instanceof Error?t.message:"Unknown error";return console.error("Error sending email via Brevo:",{error:e,stack:t instanceof Error?t.stack:void 0}),{success:!1,error:e}}}e.s(["sendBrevoEmail",()=>t])},18916,e=>{"use strict";function t(e,t){return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>${t||"Daiyet"}</title>
  <style>
    /* Email client reset */
    body, table, td, p, a, li, blockquote {
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
    }
    table, td {
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      -ms-interpolation-mode: bicubic;
      border: 0;
      height: auto;
      line-height: 100%;
      outline: none;
      text-decoration: none;
    }
    
    /* Mobile styles */
    @media only screen and (max-width: 600px) {
      .email-container {
        width: 100% !important;
        padding: 20px !important;
      }
      .email-body {
        padding: 20px !important;
      }
      .button {
        width: 100% !important;
        padding: 14px !important;
      }
      .two-column {
        width: 100% !important;
        display: block !important;
      }
      .column-left, .column-right {
        width: 100% !important;
        padding: 10px 0 !important;
      }
    }
  </style>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; background-color: #f3f4f6;">
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f3f4f6;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-container" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 8px; overflow: hidden;">
          <!-- Header -->
          <tr>
            <td style="background-color: #0a0a0a; padding: 30px 40px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">Daiyet</h1>
              <p style="margin: 8px 0 0 0; color: #9ca3af; font-size: 14px;">Scheduling reinvented</p>
            </td>
          </tr>
          
          <!-- Body Content -->
          <tr>
            <td class="email-body" style="padding: 40px; font-size: 16px; line-height: 24px; color: #111827;">
              ${e}
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px 40px; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0 0 10px 0; font-size: 14px; color: #6b7280;">
                \xa9 ${new Date().getFullYear()} Daiyet. All rights reserved.
              </p>
              <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                This email was sent to you because you have an account with Daiyet.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim()}function o(e,t,r=!0){return`
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin: 24px 0;">
      <tr>
        <td align="center">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0">
            <tr>
              <td class="button" style="border-radius: 6px; background-color: ${r?"#404040":"#ffffff"}; border: ${r?"none":"1px solid #404040"}; padding: 0;">
                <a href="${e}" style="display: inline-block; padding: 14px 28px; font-size: 16px; font-weight: 500; text-decoration: none; color: ${r?"#ffffff":"#404040"}; border-radius: 6px;">
                  ${t}
                </a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `}function r(e,i,n={}){let a={};if(!n.textOnly)switch(e){case"booking_confirmation":a.html=function(e,r=!1){let i=r?`Hello ${e.userName||"Dietitian"},<br><br>You have a new booking confirmed:`:`Hello ${e.userName||"User"},<br><br>Your booking has been confirmed!`;return t(`
    ${i}
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${e.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${e.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${e.time||"Not specified"}</td>
            </tr>
            ${e.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${e.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${e.meetingLink?o(e.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      ${r?"You can view all your bookings in your dashboard.":"We look forward to seeing you!"}
    </p>
  `,"Booking Confirmed - Daiyet")}(i,n.isDietitian);break;case"meeting_reminder":let s;s=i.reminderTime||"24 hours",a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      This is a reminder that you have a meeting scheduled in ${s}:
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${i.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.time||"Not specified"}</td>
            </tr>
            ${i.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${i.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${i.meetingLink?o(i.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      See you soon!
    </p>
  `,"Meeting Reminder - Daiyet");break;case"session_request":a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      You have a new ${i.requestType||"session"} request from your dietitian.
    </p>
    
    ${i.message?`
    <div style="margin: 24px 0; padding: 20px; background-color: #f9fafb; border-left: 4px solid #404040; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #111827; line-height: 20px;">
        ${i.message}
      </p>
    </div>
    `:""}
    
    ${i.actionRequired&&i.actionLink?o(i.actionLink,"View Request",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Please review and respond to this request at your earliest convenience.
    </p>
  `,"New Session Request - Daiyet");break;case"meal_plan_sent":a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your personalized meal plan has been prepared and is ready for you!
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px;">
          <strong style="font-size: 16px; color: #111827;">${i.mealPlanType||"Custom Meal Plan"}</strong>
          ${i.message?`
          <p style="margin: 12px 0 0 0; font-size: 14px; color: #6b7280; line-height: 20px;">
            ${i.message}
          </p>
          `:""}
        </td>
      </tr>
    </table>
    
    ${i.actionLink?o(i.actionLink,"View Meal Plan",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Your meal plan is available in your dashboard for download and reference.
    </p>
  `,"Meal Plan Ready - Daiyet");break;case"booking_rescheduled":a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your booking has been rescheduled. Here are the new details:
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${i.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">New Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">New Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.time||"Not specified"}</td>
            </tr>
            ${i.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${i.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${i.rescheduleReason?`
    <div style="margin: 24px 0; padding: 16px; background-color: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #92400e;">
        <strong>Note:</strong> ${i.rescheduleReason}
      </p>
    </div>
    `:""}
    
    ${i.meetingLink?o(i.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      We apologize for any inconvenience. We look forward to seeing you at the new time!
    </p>
  `,"Booking Rescheduled - Daiyet");break;case"booking_cancelled":a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your booking has been cancelled.
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px;">
          <strong style="font-size: 16px; color: #111827;">${i.eventTitle||"Consultation"}</strong>
          <p style="margin: 8px 0 0 0; font-size: 14px; color: #6b7280;">
            ${i.date||""} at ${i.time||""}
          </p>
        </td>
      </tr>
    </table>
    
    ${i.cancellationReason?`
    <div style="margin: 24px 0; padding: 16px; background-color: #fee2e2; border-left: 4px solid #ef4444; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #991b1b;">
        <strong>Reason:</strong> ${i.cancellationReason}
      </p>
    </div>
    `:""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      If you have any questions or would like to reschedule, please contact us or book a new appointment.
    </p>
  `,"Booking Cancelled - Daiyet");break;case"payment_confirmation":a.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${i.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your payment has been successfully processed!
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">Payment Details</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Amount:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 16px; font-weight: 600;">
                ${i.currency||"NGN"} ${i.amount||"0.00"}
              </td>
            </tr>
            ${i.eventTitle?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">For:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.eventTitle}</td>
            </tr>
            `:""}
            ${i.transactionId?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Transaction ID:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${i.transactionId}</td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Thank you for your payment. A receipt has been sent to your email.
    </p>
  `,"Payment Confirmed - Daiyet");break;default:a.html=t(`<p style="margin: 0; font-size: 16px; color: #111827;">${i.message||"You have a new message from Daiyet."}</p>`,"Message from Daiyet")}return n.htmlOnly||(a.text=function(e,t){switch(e){case"booking_confirmation":return`
Booking Confirmed!

Hello ${t.userName||"User"},

Your booking has been confirmed:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}

See you soon!
Daiyet Team
      `.trim();case"meeting_reminder":return`
Meeting Reminder

Hello ${t.userName||"User"},

This is a reminder that you have a meeting scheduled:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}

See you soon!
Daiyet Team
      `.trim();case"session_request":return`
New Session Request

Hello ${t.userName||"User"},

You have a new ${t.requestType||"session"} request from your dietitian.

${t.message||""}

${t.actionLink?`Action required: ${t.actionLink}`:""}

Daiyet Team
      `.trim();case"meal_plan_sent":return`
Meal Plan Ready

Hello ${t.userName||"User"},

Your personalized meal plan (${t.mealPlanType||"Custom Meal Plan"}) has been prepared and is ready for you!

${t.message||""}

${t.actionLink?`View Meal Plan: ${t.actionLink}`:""}

Your meal plan is available in your dashboard.

Daiyet Team
      `.trim();case"booking_rescheduled":return`
Booking Rescheduled

Hello ${t.userName||"User"},

Your booking has been rescheduled. New details:
- Event: ${t.eventTitle||"Consultation"}
- New Date: ${t.date||""}
- New Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}
${t.rescheduleReason?`
Reason: ${t.rescheduleReason}`:""}

We apologize for any inconvenience.

Daiyet Team
      `.trim();case"booking_cancelled":return`
Booking Cancelled

Hello ${t.userName||"User"},

Your booking has been cancelled:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.cancellationReason?`
Reason: ${t.cancellationReason}`:""}

If you have any questions, please contact us.

Daiyet Team
      `.trim();case"payment_confirmation":return`
Payment Confirmed

Hello ${t.userName||"User"},

Your payment has been successfully processed!

Amount: ${t.currency||"NGN"} ${t.amount||"0.00"}
${t.eventTitle?`For: ${t.eventTitle}`:""}
${t.transactionId?`Transaction ID: ${t.transactionId}`:""}

Thank you for your payment. A receipt has been sent to your email.

Daiyet Team
      `.trim();default:return t.message||"You have a new message from Daiyet."}}(e,i)),a}e.s(["getEmailTemplate",()=>r])},99875,e=>{"use strict";var t=e.i(89660),o=e.i(88841),r=e.i(18916);let i=new class{isProcessing=!1;processingInterval=null;async enqueue(e,o={}){let r=o.delay?new Date(Date.now()+o.delay).toISOString():new Date().toISOString();try{let o=(0,t.createAdminClientServer)(),{data:i,error:n}=await o.from("email_queue").insert({type:"email",payload:e,scheduled_for:r,status:"pending",attempts:0,max_attempts:3}).select().single();if(n)throw console.error("Error enqueueing email:",n),Error(`Failed to enqueue email: ${n.message}`);return i}catch(e){throw console.error("Error in enqueue:",e),e}}async sendEmailWithRetry(e){for(let t=1;t<=3;t++)try{console.log(`Attempt ${t} to send email to ${e.to} (template: ${e.template})`);let i=(0,r.getEmailTemplate)(e.template,e.data,{isDietitian:e.isDietitian||!1}),n={to:e.to,subject:e.subject,htmlContent:i.html,textContent:i.text,from:e.from,fromName:e.fromName,replyTo:e.replyTo,tags:e.tags||[e.template]},a=await (0,o.sendBrevoEmail)(n);if(a.success)return console.log(`Email sent successfully to ${e.to} (messageId: ${a.messageId||"N/A"})`),{success:!0};if(a.error&&a.error.includes("4")&&!a.error.includes("429"))return console.error(`Permanent error, not retrying: ${a.error}`),a;if(t<3){let e=1e3*Math.pow(2,t-1),o=.2*e*Math.random();console.log(`Retrying in ${Math.round(e+o)}ms...`),await new Promise(t=>setTimeout(t,e+o))}}catch(e){if(console.error(`Email attempt ${t} exception:`,e),3===t)return{success:!1,error:e instanceof Error?e.message:"Unknown error"}}return{success:!1,error:"Max retries exceeded"}}startProcessing(e=3e4){this.processingInterval||(this.processingInterval=setInterval(async()=>{if(!this.isProcessing){this.isProcessing=!0;try{await this.processQueue()}catch(e){console.error("Queue processing error:",e)}finally{this.isProcessing=!1}}},e))}async processQueue(){let e=(0,t.createAdminClientServer)(),{data:o,error:r}=await e.from("email_queue").select("*").eq("status","pending").lte("scheduled_for",new Date().toISOString()).order("created_at",{ascending:!0}).limit(20);if(r)throw r;if(o&&0!==o.length)for(let t=0;t<o.length;t+=5){let r=o.slice(t,t+5);await Promise.allSettled(r.map(async t=>{await e.from("email_queue").update({status:"processing",attempts:t.attempts+1,last_attempt_at:new Date().toISOString()}).eq("id",t.id);let o=await this.sendEmailWithRetry(t.payload);if(o.success)await e.from("email_queue").update({status:"completed",completed_at:new Date().toISOString()}).eq("id",t.id);else if(t.attempts+1>=t.max_attempts)await e.from("email_dead_letter_queue").insert({original_id:t.id,payload:t.payload,error:o.error,attempts:t.attempts+1}),await e.from("email_queue").update({status:"failed"}).eq("id",t.id);else{let o=Math.min(36e5,6e4*Math.pow(2,t.attempts));await e.from("email_queue").update({status:"pending",scheduled_for:new Date(Date.now()+o).toISOString()}).eq("id",t.id)}}))}}stopProcessing(){this.processingInterval&&(clearInterval(this.processingInterval),this.processingInterval=null)}async processQueuePublic(){if(!this.isProcessing){this.isProcessing=!0;try{let e=(0,t.createAdminClientServer)(),{data:o,error:r}=await e.from("email_queue").select("*").eq("status","pending").lte("scheduled_for",new Date().toISOString()).order("created_at",{ascending:!0}).limit(20);if(r)throw r;if(!o||0===o.length)return;for(let t=0;t<o.length;t+=5){let r=o.slice(t,t+5);await Promise.allSettled(r.map(async t=>{await e.from("email_queue").update({status:"processing",attempts:t.attempts+1,last_attempt_at:new Date().toISOString()}).eq("id",t.id);let o=await this.sendEmailWithRetry(t.payload);if(o.success)await e.from("email_queue").update({status:"completed",completed_at:new Date().toISOString()}).eq("id",t.id);else if(t.attempts+1>=t.max_attempts)await e.from("email_dead_letter_queue").insert({original_id:t.id,payload:t.payload,error:o.error,attempts:t.attempts+1}),await e.from("email_queue").update({status:"failed"}).eq("id",t.id);else{let o=Math.min(36e5,6e4*Math.pow(2,t.attempts));await e.from("email_queue").update({status:"pending",scheduled_for:new Date(Date.now()+o).toISOString()}).eq("id",t.id)}}))}}catch(e){console.error("Queue processing error:",e)}finally{this.isProcessing=!1}}}};i.startProcessing(),e.s(["emailQueue",0,i])}];

//# sourceMappingURL=lib_email_8e437430._.js.map