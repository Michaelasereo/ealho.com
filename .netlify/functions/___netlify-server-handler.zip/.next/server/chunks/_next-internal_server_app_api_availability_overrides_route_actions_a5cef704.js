module.exports=[15655,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_availability_overrides_route_actions_a5cef704.js.map