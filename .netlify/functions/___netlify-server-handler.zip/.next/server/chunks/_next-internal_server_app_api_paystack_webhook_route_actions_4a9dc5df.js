module.exports=[67888,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paystack_webhook_route_actions_4a9dc5df.js.map