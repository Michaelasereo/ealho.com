module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70864,a=>{a.n(a.i(33290))},43619,a=>{a.n(a.i(79962))},13718,a=>{a.n(a.i(85523))},18198,a=>{a.n(a.i(45518))},62212,a=>{a.n(a.i(66114))},64599,a=>{a.n(a.i(54022))},28593,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/app/user-dashboard/session-notes/SessionNotesPageClient.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/app/user-dashboard/session-notes/SessionNotesPageClient.tsx <module evaluation>","default");a.s(["default",0,b])},51782,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/app/user-dashboard/session-notes/SessionNotesPageClient.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/app/user-dashboard/session-notes/SessionNotesPageClient.tsx","default");a.s(["default",0,b])},1446,a=>{"use strict";a.i(28593);var b=a.i(51782);a.n(b)},26558,a=>{"use strict";var b=a.i(7997);a.i(70396);var c=a.i(73727),d=a.i(25306),e=a.i(98310),f=a.i(1446);async function g(){try{let a=await (0,d.createClient)(),{data:{user:g},error:h}=await a.auth.getUser();(h||!g)&&(console.error("Session Notes: No user found",{error:h?.message,hasUser:!!g,timestamp:new Date().toISOString()}),(0,c.redirect)("/login?redirect=/user-dashboard/session-notes"));let i=(0,e.createAdminClientServer)(),{data:j,error:k}=await i.from("users").select("id, role, account_status").eq("id",g.id).single();(k||!j)&&(console.error("Session Notes: User not found in database",{error:k?.message,userId:g.id,timestamp:new Date().toISOString()}),(0,c.redirect)("/login")),"USER"!==j.role&&("THERAPIST"===j.role?(0,c.redirect)("/therapist-dashboard/session-notes"):"DIETITIAN"===j.role?(0,c.redirect)("/dashboard"):"ADMIN"===j.role?(0,c.redirect)("/admin"):(0,c.redirect)("/"));let{data:l,error:m}=await i.from("session_notes").select(`
        id,
        booking_id,
        therapist_id,
        client_id,
        client_name,
        session_number,
        session_date,
        session_time,
        therapist_name,
        location,
        patient_complaint,
        personal_history,
        family_history,
        presentation,
        formulation_and_diagnosis,
        treatment_plan,
        assignments,
        status,
        created_at,
        updated_at,
        completed_at,
        bookings (
          id,
          title,
          start_time,
          end_time,
          status as booking_status
        ),
        therapist:users!session_notes_therapist_id_fkey (
          id,
          name,
          email
        )
      `).eq("client_id",j.id).order("session_date",{ascending:!1});return(0,b.jsx)(f.default,{notes:l&&!m?l:[]})}catch(a){console.error("Session Notes: Server error",a),(0,c.redirect)("/login?redirect=/user-dashboard/session-notes")}}a.s(["default",()=>g])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__7520a60e._.js.map