module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70864,a=>{a.n(a.i(33290))},43619,a=>{a.n(a.i(79962))},13718,a=>{a.n(a.i(85523))},18198,a=>{a.n(a.i(45518))},62212,a=>{a.n(a.i(66114))},22882,a=>{a.n(a.i(46927))},80023,a=>{a.n(a.i(69303))},30205,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/app/dashboard/bookings/BookingsPageClient.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/app/dashboard/bookings/BookingsPageClient.tsx <module evaluation>","default");a.s(["default",0,b])},11743,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/app/dashboard/bookings/BookingsPageClient.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/app/dashboard/bookings/BookingsPageClient.tsx","default");a.s(["default",0,b])},25472,a=>{"use strict";a.i(30205);var b=a.i(11743);a.n(b)},52777,a=>{"use strict";var b=a.i(7997);a.i(70396);var c=a.i(73727),d=a.i(25306),e=a.i(98310),f=a.i(25472);async function g(){try{let a=await (0,d.createClient)(),{data:{user:g},error:h}=await a.auth.getUser();(h||!g)&&(console.error("Past Bookings: No user found",{error:h?.message,hasUser:!!g,timestamp:new Date().toISOString()}),(0,c.redirect)("/dietitian-login?redirect=/dashboard/bookings/past"));let i=(0,e.createAdminClientServer)(),{data:j,error:k}=await i.from("users").select("id, role, account_status").eq("id",g.id).single();(k||!j)&&(console.error("Past Bookings: User not found in database",{error:k?.message,userId:g.id,timestamp:new Date().toISOString()}),(0,c.redirect)("/dietitian-enrollment")),"DIETITIAN"!==j.role&&(console.error("Past Bookings: User is not dietitian",{role:j.role,userId:g.id,timestamp:new Date().toISOString()}),"USER"===j.role?(0,c.redirect)("/user-dashboard"):"ADMIN"===j.role?(0,c.redirect)("/admin"):(0,c.redirect)("/")),"ACTIVE"!==j.account_status&&(console.error("Past Bookings: Account not active",{status:j.account_status,userId:g.id,timestamp:new Date().toISOString()}),(0,c.redirect)("/account-status"));let l=j.id;new Date().toISOString();let{data:m,error:n}=await i.from("bookings").select(`
        id,
        start_time,
        end_time,
        title,
        description,
        meeting_link,
        status,
        event_types:event_type_id (
          id,
          title,
          slug
        ),
        user:users!bookings_user_id_fkey (
          name,
          email
        )
      `).eq("dietitian_id",l).order("start_time",{ascending:!1}),o=m&&!n?m.filter(a=>{let b=new Date(a.start_time)<new Date,c="COMPLETED"===a.status;return b||c}).map(a=>({id:a.id,date:new Date(a.start_time),startTime:new Date(a.start_time),endTime:new Date(a.end_time),title:a.title||a.event_types?.title||"Consultation",eventTypeSlug:a.event_types?.slug||null,description:a.description||"",message:a.description,participants:["You",a.user?.name||a.user?.email||"Client"],meetingLink:a.meeting_link||void 0})):[];return(0,b.jsx)(f.default,{bookings:o,type:"past"})}catch(a){console.error("Past Bookings: Server error",a),(0,c.redirect)("/dietitian-login?redirect=/dashboard/bookings/past")}}a.s(["default",()=>g])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__787b8188._.js.map