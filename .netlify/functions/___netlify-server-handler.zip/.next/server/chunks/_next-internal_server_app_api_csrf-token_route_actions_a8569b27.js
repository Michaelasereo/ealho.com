module.exports=[89051,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_csrf-token_route_actions_a8569b27.js.map