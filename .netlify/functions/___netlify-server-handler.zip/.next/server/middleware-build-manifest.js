globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5184595130cbc579.js",
    "static/chunks/4230d8e6a73cea70.js",
    "static/chunks/e80a198193f3eecb.js",
    "static/chunks/86c14b89537c4484.js",
    "static/chunks/c462f7822a1dbf4e.js",
    "static/chunks/turbopack-44ea3bf50a521792.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];