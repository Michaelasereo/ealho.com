module.exports=[45454,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_email_process_route_actions_c9e43b5e.js.map