module.exports=[81583,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_therapist-dashboard_page_actions_3262bf9f.js.map