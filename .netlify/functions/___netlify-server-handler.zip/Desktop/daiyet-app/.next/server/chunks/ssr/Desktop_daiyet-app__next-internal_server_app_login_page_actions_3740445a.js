module.exports=[72215,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_login_page_actions_3740445a.js.map