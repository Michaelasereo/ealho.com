module.exports=[21467,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_availability_timeslots_route_actions_7bf4fe43.js.map