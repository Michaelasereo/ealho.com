module.exports=[25518,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_dashboard_page_actions_5a9c27c2.js.map