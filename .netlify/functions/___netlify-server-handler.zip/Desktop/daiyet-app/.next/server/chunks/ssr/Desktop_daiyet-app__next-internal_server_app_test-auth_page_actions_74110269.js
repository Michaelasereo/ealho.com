module.exports=[72993,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_test-auth_page_actions_74110269.js.map