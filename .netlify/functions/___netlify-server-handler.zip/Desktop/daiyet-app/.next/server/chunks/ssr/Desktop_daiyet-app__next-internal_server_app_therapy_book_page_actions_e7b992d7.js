module.exports=[91347,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_therapy_book_page_actions_e7b992d7.js.map