module.exports=[52979,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_test-upload-flow_page_actions_3d6f4016.js.map