module.exports=[27672,(a,b,c)=>{}];

//# sourceMappingURL=3a061_next-internal_server_app_therapist-dashboard_availability_page_actions_43b9e9b2.js.map