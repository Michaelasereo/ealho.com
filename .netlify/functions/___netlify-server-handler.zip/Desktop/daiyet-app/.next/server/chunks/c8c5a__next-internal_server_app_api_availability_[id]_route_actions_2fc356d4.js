module.exports=[51676,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_availability_%5Bid%5D_route_actions_2fc356d4.js.map