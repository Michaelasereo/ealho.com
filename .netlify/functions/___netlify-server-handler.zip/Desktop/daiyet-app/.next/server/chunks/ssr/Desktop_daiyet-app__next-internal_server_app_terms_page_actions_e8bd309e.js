module.exports=[26115,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_terms_page_actions_e8bd309e.js.map