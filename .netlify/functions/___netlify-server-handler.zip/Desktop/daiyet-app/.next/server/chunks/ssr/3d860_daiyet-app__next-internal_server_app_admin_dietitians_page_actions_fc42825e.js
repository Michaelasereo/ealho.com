module.exports=[87546,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_dietitians_page_actions_fc42825e.js.map