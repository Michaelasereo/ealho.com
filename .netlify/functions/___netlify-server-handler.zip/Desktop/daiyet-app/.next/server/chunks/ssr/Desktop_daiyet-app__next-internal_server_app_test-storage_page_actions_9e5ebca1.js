module.exports=[77036,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_test-storage_page_actions_9e5ebca1.js.map