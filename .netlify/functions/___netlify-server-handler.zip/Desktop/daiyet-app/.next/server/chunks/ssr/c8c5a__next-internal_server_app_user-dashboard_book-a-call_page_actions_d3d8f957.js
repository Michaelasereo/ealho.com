module.exports=[71838,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_user-dashboard_book-a-call_page_actions_d3d8f957.js.map