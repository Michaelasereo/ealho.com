module.exports=[33025,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_availability_out-of-office_route_actions_6fff88dd.js.map