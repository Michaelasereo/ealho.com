module.exports=[59358,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_privacy_page_actions_b81a7fcf.js.map