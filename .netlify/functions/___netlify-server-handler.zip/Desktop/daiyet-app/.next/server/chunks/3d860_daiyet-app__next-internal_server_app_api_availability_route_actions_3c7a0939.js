module.exports=[21079,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_availability_route_actions_3c7a0939.js.map