module.exports=[87928,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_bookings_upcoming_page_actions_b0e8591e.js.map