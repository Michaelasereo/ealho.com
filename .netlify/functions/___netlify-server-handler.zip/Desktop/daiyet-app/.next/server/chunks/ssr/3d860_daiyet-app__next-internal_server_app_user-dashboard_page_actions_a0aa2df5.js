module.exports=[51941,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_user-dashboard_page_actions_a0aa2df5.js.map