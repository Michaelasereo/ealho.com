module.exports=[98168,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_book_%5Bdietitian%5D_page_actions_2d074e7d.js.map