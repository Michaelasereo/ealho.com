module.exports=[7993,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_api_health_route_actions_b061e96e.js.map