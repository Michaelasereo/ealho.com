module.exports=[37041,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_therapists_enroll_route_actions_cdb33bd4.js.map