module.exports=[5481,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_event-types_route_actions_c318b018.js.map