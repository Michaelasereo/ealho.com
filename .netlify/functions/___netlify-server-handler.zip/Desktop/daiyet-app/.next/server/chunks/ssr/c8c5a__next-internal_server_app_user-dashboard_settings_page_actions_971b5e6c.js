module.exports=[51498,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_user-dashboard_settings_page_actions_971b5e6c.js.map