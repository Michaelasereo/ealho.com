module.exports=[611,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_therapists_by-slug_%5Bslug%5D_route_actions_6e700655.js.map