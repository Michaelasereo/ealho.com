module.exports=[69600,a=>{"use strict";var b=a.i(82138);function c(){(0,b.redirect)("/user-dashboard/settings/profile")}a.s(["default",()=>c])}];

//# sourceMappingURL=Desktop_daiyet-app_app_user-dashboard_settings_page_tsx_493ab476._.js.map