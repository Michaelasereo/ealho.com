module.exports=[93695,(e,t,n)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,n)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,n)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,n)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,n)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,n)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},32461,e=>{"use strict";function t(e,t){return`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>${t||"Daiyet"}</title>
  <style>
    /* Email client reset */
    body, table, td, p, a, li, blockquote {
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
    }
    table, td {
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
    }
    img {
      -ms-interpolation-mode: bicubic;
      border: 0;
      height: auto;
      line-height: 100%;
      outline: none;
      text-decoration: none;
    }
    
    /* Mobile styles */
    @media only screen and (max-width: 600px) {
      .email-container {
        width: 100% !important;
        padding: 20px !important;
      }
      .email-body {
        padding: 20px !important;
      }
      .button {
        width: 100% !important;
        padding: 14px !important;
      }
      .two-column {
        width: 100% !important;
        display: block !important;
      }
      .column-left, .column-right {
        width: 100% !important;
        padding: 10px 0 !important;
      }
    }
  </style>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; background-color: #f3f4f6;">
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f3f4f6;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-container" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 8px; overflow: hidden;">
          <!-- Header -->
          <tr>
            <td style="background-color: #0a0a0a; padding: 30px 40px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">Daiyet</h1>
              <p style="margin: 8px 0 0 0; color: #9ca3af; font-size: 14px;">Scheduling reinvented</p>
            </td>
          </tr>
          
          <!-- Body Content -->
          <tr>
            <td class="email-body" style="padding: 40px; font-size: 16px; line-height: 24px; color: #111827;">
              ${e}
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px 40px; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="margin: 0 0 10px 0; font-size: 14px; color: #6b7280;">
                \xa9 ${new Date().getFullYear()} Daiyet. All rights reserved.
              </p>
              <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                This email was sent to you because you have an account with Daiyet.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim()}function n(e,t,r=!0){return`
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin: 24px 0;">
      <tr>
        <td align="center">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0">
            <tr>
              <td class="button" style="border-radius: 6px; background-color: ${r?"#404040":"#ffffff"}; border: ${r?"none":"1px solid #404040"}; padding: 0;">
                <a href="${e}" style="display: inline-block; padding: 14px 28px; font-size: 16px; font-weight: 500; text-decoration: none; color: ${r?"#ffffff":"#404040"}; border-radius: 6px;">
                  ${t}
                </a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `}function r(e,o,a={}){let i={};if(!a.textOnly)switch(e){case"booking_confirmation":i.html=function(e,r=!1){let o=r?`Hello ${e.userName||"Dietitian"},<br><br>You have a new booking confirmed:`:`Hello ${e.userName||"User"},<br><br>Your booking has been confirmed!`;return t(`
    ${o}
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${e.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${e.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${e.time||"Not specified"}</td>
            </tr>
            ${e.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${e.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${e.meetingLink?n(e.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      ${r?"You can view all your bookings in your dashboard.":"We look forward to seeing you!"}
    </p>
  `,"Booking Confirmed - Daiyet")}(o,a.isDietitian);break;case"meeting_reminder":let s;s=o.reminderTime||"24 hours",i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      This is a reminder that you have a meeting scheduled in ${s}:
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${o.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.time||"Not specified"}</td>
            </tr>
            ${o.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${o.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${o.meetingLink?n(o.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      See you soon!
    </p>
  `,"Meeting Reminder - Daiyet");break;case"session_request":i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      You have a new ${o.requestType||"session"} request from your dietitian.
    </p>
    
    ${o.message?`
    <div style="margin: 24px 0; padding: 20px; background-color: #f9fafb; border-left: 4px solid #404040; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #111827; line-height: 20px;">
        ${o.message}
      </p>
    </div>
    `:""}
    
    ${o.actionRequired&&o.actionLink?n(o.actionLink,"View Request",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Please review and respond to this request at your earliest convenience.
    </p>
  `,"New Session Request - Daiyet");break;case"meal_plan_sent":i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your personalized meal plan has been prepared and is ready for you!
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px;">
          <strong style="font-size: 16px; color: #111827;">${o.mealPlanType||"Custom Meal Plan"}</strong>
          ${o.message?`
          <p style="margin: 12px 0 0 0; font-size: 14px; color: #6b7280; line-height: 20px;">
            ${o.message}
          </p>
          `:""}
        </td>
      </tr>
    </table>
    
    ${o.actionLink?n(o.actionLink,"View Meal Plan",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Your meal plan is available in your dashboard for download and reference.
    </p>
  `,"Meal Plan Ready - Daiyet");break;case"booking_rescheduled":i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your booking has been rescheduled. Here are the new details:
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">${o.eventTitle||"Consultation"}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">New Date:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.date||"Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">New Time:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.time||"Not specified"}</td>
            </tr>
            ${o.meetingLink?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Meeting:</td>
              <td style="padding: 8px 0;">
                <a href="${o.meetingLink}" style="color: #404040; text-decoration: underline; font-size: 14px;">Join Meeting</a>
              </td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    ${o.rescheduleReason?`
    <div style="margin: 24px 0; padding: 16px; background-color: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #92400e;">
        <strong>Note:</strong> ${o.rescheduleReason}
      </p>
    </div>
    `:""}
    
    ${o.meetingLink?n(o.meetingLink,"Join Meeting",!0):""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      We apologize for any inconvenience. We look forward to seeing you at the new time!
    </p>
  `,"Booking Rescheduled - Daiyet");break;case"booking_cancelled":i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your booking has been cancelled.
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px;">
          <strong style="font-size: 16px; color: #111827;">${o.eventTitle||"Consultation"}</strong>
          <p style="margin: 8px 0 0 0; font-size: 14px; color: #6b7280;">
            ${o.date||""} at ${o.time||""}
          </p>
        </td>
      </tr>
    </table>
    
    ${o.cancellationReason?`
    <div style="margin: 24px 0; padding: 16px; background-color: #fee2e2; border-left: 4px solid #ef4444; border-radius: 4px;">
      <p style="margin: 0; font-size: 14px; color: #991b1b;">
        <strong>Reason:</strong> ${o.cancellationReason}
      </p>
    </div>
    `:""}
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      If you have any questions or would like to reschedule, please contact us or book a new appointment.
    </p>
  `,"Booking Cancelled - Daiyet");break;case"payment_confirmation":i.html=t(`
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Hello ${o.userName||"User"},
    </p>
    
    <p style="margin: 0 0 24px 0; font-size: 16px; color: #111827;">
      Your payment has been successfully processed!
    </p>
    
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 24px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
      <tr>
        <td style="padding: 20px; background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 18px; color: #111827;">Payment Details</strong>
        </td>
      </tr>
      <tr>
        <td style="padding: 20px;">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Amount:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 16px; font-weight: 600;">
                ${o.currency||"NGN"} ${o.amount||"0.00"}
              </td>
            </tr>
            ${o.eventTitle?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">For:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.eventTitle}</td>
            </tr>
            `:""}
            ${o.transactionId?`
            <tr>
              <td style="padding: 8px 0; color: #6b7280; font-size: 14px;">Transaction ID:</td>
              <td style="padding: 8px 0; color: #111827; font-size: 14px; font-weight: 500;">${o.transactionId}</td>
            </tr>
            `:""}
          </table>
        </td>
      </tr>
    </table>
    
    <p style="margin: 24px 0 0 0; font-size: 14px; color: #6b7280;">
      Thank you for your payment. A receipt has been sent to your email.
    </p>
  `,"Payment Confirmed - Daiyet");break;default:i.html=t(`<p style="margin: 0; font-size: 16px; color: #111827;">${o.message||"You have a new message from Daiyet."}</p>`,"Message from Daiyet")}return a.htmlOnly||(i.text=function(e,t){switch(e){case"booking_confirmation":return`
Booking Confirmed!

Hello ${t.userName||"User"},

Your booking has been confirmed:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}

See you soon!
Daiyet Team
      `.trim();case"meeting_reminder":return`
Meeting Reminder

Hello ${t.userName||"User"},

This is a reminder that you have a meeting scheduled:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}

See you soon!
Daiyet Team
      `.trim();case"session_request":return`
New Session Request

Hello ${t.userName||"User"},

You have a new ${t.requestType||"session"} request from your dietitian.

${t.message||""}

${t.actionLink?`Action required: ${t.actionLink}`:""}

Daiyet Team
      `.trim();case"meal_plan_sent":return`
Meal Plan Ready

Hello ${t.userName||"User"},

Your personalized meal plan (${t.mealPlanType||"Custom Meal Plan"}) has been prepared and is ready for you!

${t.message||""}

${t.actionLink?`View Meal Plan: ${t.actionLink}`:""}

Your meal plan is available in your dashboard.

Daiyet Team
      `.trim();case"booking_rescheduled":return`
Booking Rescheduled

Hello ${t.userName||"User"},

Your booking has been rescheduled. New details:
- Event: ${t.eventTitle||"Consultation"}
- New Date: ${t.date||""}
- New Time: ${t.time||""}
${t.meetingLink?`- Meeting Link: ${t.meetingLink}`:""}
${t.rescheduleReason?`
Reason: ${t.rescheduleReason}`:""}

We apologize for any inconvenience.

Daiyet Team
      `.trim();case"booking_cancelled":return`
Booking Cancelled

Hello ${t.userName||"User"},

Your booking has been cancelled:
- Event: ${t.eventTitle||"Consultation"}
- Date: ${t.date||""}
- Time: ${t.time||""}
${t.cancellationReason?`
Reason: ${t.cancellationReason}`:""}

If you have any questions, please contact us.

Daiyet Team
      `.trim();case"payment_confirmation":return`
Payment Confirmed

Hello ${t.userName||"User"},

Your payment has been successfully processed!

Amount: ${t.currency||"NGN"} ${t.amount||"0.00"}
${t.eventTitle?`For: ${t.eventTitle}`:""}
${t.transactionId?`Transaction ID: ${t.transactionId}`:""}

Thank you for your payment. A receipt has been sent to your email.

Daiyet Team
      `.trim();default:return t.message||"You have a new message from Daiyet."}}(e,o)),i}e.s(["getEmailTemplate",()=>r])},74574,e=>{"use strict";async function t(e){let t=process.env.BREVO_API_KEY,n=process.env.BREVO_SENDER_EMAIL||"noreply@daiyet.co",r=process.env.BREVO_SENDER_NAME||"Daiyet";if(!t)return console.error("BREVO_API_KEY is not configured"),{success:!1,error:"Email service not configured"};if(!e.to||!e.subject)return{success:!1,error:"Missing required fields: to and subject are required"};if(!e.htmlContent&&!e.textContent)return{success:!1,error:"Either htmlContent or textContent must be provided"};try{let o=Array.isArray(e.to)?e.to.map(e=>({email:e})):[{email:e.to}],a={sender:{name:e.fromName||r,email:e.from||n},to:o,subject:e.subject,htmlContent:e.htmlContent||void 0,textContent:e.textContent||void 0};e.replyTo&&(a.replyTo={email:e.replyTo.email,name:e.replyTo.name}),e.attachments&&e.attachments.length>0&&(a.attachment=e.attachments),e.tags&&e.tags.length>0&&(a.tags=e.tags),e.params&&(a.params=e.params);let i=await fetch("https://api.brevo.com/v3/smtp/email",{method:"POST",headers:{"api-key":t,"Content-Type":"application/json"},body:JSON.stringify(a)});if(!i.ok){let e=await i.text(),t=`Brevo API error: ${i.status}`;try{let n=JSON.parse(e);t=n.message||n.error||t}catch{t=e||t}return console.error("Brevo API error:",{status:i.status,statusText:i.statusText,error:t}),{success:!1,error:t}}let s=await i.json();return console.log("Email sent successfully via Brevo:",{messageId:s.messageId,to:Array.isArray(e.to)?`${e.to.length} recipients`:e.to,subject:e.subject}),{success:!0,messageId:s.messageId}}catch(t){let e=t instanceof Error?t.message:"Unknown error";return console.error("Error sending email via Brevo:",{error:e,stack:t instanceof Error?t.stack:void 0}),{success:!1,error:e}}}e.s(["sendBrevoEmail",()=>t])},68781,e=>{"use strict";var t=e.i(30872),n=e.i(97319),r=e.i(4938),o=e.i(13208),a=e.i(80429),i=e.i(73910),s=e.i(60143),l=e.i(88185),d=e.i(71754),p=e.i(83052),c=e.i(56847),u=e.i(54267),m=e.i(72910),g=e.i(84321),f=e.i(30917),x=e.i(69398),y=e.i(93695);e.i(17464);var b=e.i(19178),h=e.i(25588),v=e.i(32461),k=e.i(74574);async function w(e){try{let{emailType:t,recipientEmail:n,preview:r}=await e.json();if(!t||!n)return h.NextResponse.json({error:"emailType and recipientEmail are required"},{status:400});let o=function(e){let t={userName:"Test User",eventTitle:"1-on-1 Consultation with Licensed Dietician",date:new Date(Date.now()+6048e5).toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"}),time:"10:00 AM",meetingLink:"https://meet.google.com/abc-defg-hij",message:"This is a test email to verify the email template is working correctly.",requestType:"CONSULTATION",mealPlanType:"Weight Loss Plan",amount:"15,000",currency:"NGN",transactionId:"TXN-TEST-123456",rescheduleReason:"Dietitian requested reschedule due to scheduling conflict",cancellationReason:"User requested cancellation",reminderTime:"24 hours",actionLink:"https://daiyet.co/user-dashboard/book-a-call",actionRequired:!0};switch(e){case"booking_confirmation":case"booking_confirmation_dietitian":return{...t,userName:"booking_confirmation_dietitian"===e?"Dr. Test Dietitian":"Test User"};case"meeting_reminder":return{...t,reminderTime:"24 hours"};case"booking_cancelled":return{...t,cancellationReason:"Test cancellation reason"};case"session_request":return{...t,requestType:"CONSULTATION",message:"Your dietitian has sent you a consultation request. Please review and respond."};case"meal_plan_sent":return{...t,mealPlanType:"Weight Loss Plan",message:"Your personalized meal plan has been prepared based on your consultation."};case"payment_confirmation":return{...t,amount:"15,000",currency:"NGN",transactionId:"TXN-TEST-123456"};case"booking_rescheduled":return{...t,rescheduleReason:"Dietitian requested reschedule due to scheduling conflict"};default:return t}}(t),a="booking_confirmation_dietitian"===t,i=a?"booking_confirmation":t,{html:s,text:l}=(0,v.getEmailTemplate)(i,o,{isDietitian:a});if(r)return h.NextResponse.json({html:s||""});let d=await (0,k.sendBrevoEmail)({to:n,subject:{booking_confirmation:"Booking Confirmed - Daiyet",booking_confirmation_dietitian:"New Booking Confirmed - Daiyet",meeting_reminder:"Meeting Reminder - Daiyet",booking_cancelled:"Booking Cancelled - Daiyet",session_request:"New Session Request - Daiyet",meal_plan_sent:"Meal Plan Ready - Daiyet",payment_confirmation:"Payment Confirmed - Daiyet",booking_rescheduled:"Booking Rescheduled - Daiyet"}[t]||"Test Email - Daiyet",htmlContent:s,textContent:l,tags:["test-email",t]});if(!d.success)return h.NextResponse.json({success:!1,error:d.error||"Failed to send email"},{status:500});return h.NextResponse.json({success:!0,message:`Test email sent successfully to ${n}`,messageId:d.messageId})}catch(e){return console.error("Error in test email endpoint:",e),h.NextResponse.json({success:!1,error:e.message||"Internal server error"},{status:500})}}e.s(["POST",()=>w],7424);var $=e.i(7424);let T=new t.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/admin/test-email/route",pathname:"/api/admin/test-email",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/daiyet-app/app/api/admin/test-email/route.ts",nextConfigOutput:"standalone",userland:$}),{workAsyncStorage:R,workUnitAsyncStorage:N,serverHooks:E}=T;function C(){return(0,r.patchFetch)({workAsyncStorage:R,workUnitAsyncStorage:N})}async function z(e,t,r){T.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let h="/api/admin/test-email/route";h=h.replace(/\/index$/,"")||"/";let v=await T.prepare(e,t,{srcPage:h,multiZoneDraftMode:!1});if(!v)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:k,params:w,nextConfig:$,parsedUrl:R,isDraftMode:N,prerenderManifest:E,routerServerContext:C,isOnDemandRevalidate:z,revalidateOnlyGenerated:D,resolvedPathname:_,clientReferenceManifest:A,serverActionsManifest:q}=v,P=(0,l.normalizeAppPath)(h),M=!!(E.dynamicRoutes[P]||E.routes[_]),L=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,R,!1):t.end("This page could not be found"),null);if(M&&!N){let e=!!E.routes[_],t=E.dynamicRoutes[P];if(t&&!1===t.fallback&&!e){if($.experimental.adapterPath)return await L();throw new y.NoFallbackError}}let I=null;!M||T.isDev||N||(I="/index"===(I=_)?"/":I);let S=!0===T.isDev||!M,U=M&&!S;q&&A&&(0,i.setReferenceManifestsSingleton)({page:h,clientReferenceManifest:A,serverActionsManifest:q,serverModuleMap:(0,s.createServerModuleMap)({serverActionsManifest:q})});let O=e.method||"GET",j=(0,a.getTracer)(),H=j.getActiveScopeSpan(),B={params:w,prerenderManifest:E,renderOpts:{experimental:{authInterrupts:!!$.experimental.authInterrupts},cacheComponents:!!$.cacheComponents,supportsDynamicResponse:S,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:$.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,n,r)=>T.onRequestError(e,t,r,C)},sharedContext:{buildId:k}},Y=new d.NodeNextRequest(e),F=new d.NodeNextResponse(t),K=p.NextRequestAdapter.fromNodeNextRequest(Y,(0,p.signalFromNodeResponse)(t));try{let i=async e=>T.handle(K,B).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let n=j.getRootSpanAttributes();if(!n)return;if(n.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${n.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=n.get("next.route");if(r){let t=`${O} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${O} ${h}`)}),s=!!(0,o.getRequestMeta)(e,"minimalMode"),l=async o=>{var a,l;let d=async({previousCacheEntry:n})=>{try{if(!s&&z&&D&&!n)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await i(o);e.fetchMetrics=B.renderOpts.fetchMetrics;let l=B.renderOpts.pendingWaitUntil;l&&r.waitUntil&&(r.waitUntil(l),l=void 0);let d=B.renderOpts.collectedTags;if(!M)return await (0,m.sendResponse)(Y,F,a,B.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(a.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let n=void 0!==B.renderOpts.collectedRevalidate&&!(B.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&B.renderOpts.collectedRevalidate,r=void 0===B.renderOpts.collectedExpire||B.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:B.renderOpts.collectedExpire;return{value:{kind:b.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:n,expire:r}}}}catch(t){throw(null==n?void 0:n.isStale)&&await T.onRequestError(e,t,{routerKind:"App Router",routePath:h,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:z})},C),t}},p=await T.handleResponse({req:e,nextConfig:$,cacheKey:I,routeKind:n.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:E,isRoutePPREnabled:!1,isOnDemandRevalidate:z,revalidateOnlyGenerated:D,responseGenerator:d,waitUntil:r.waitUntil,isMinimalMode:s});if(!M)return null;if((null==p||null==(a=p.value)?void 0:a.kind)!==b.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});s||t.setHeader("x-nextjs-cache",z?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,g.fromNodeOutgoingHttpHeaders)(p.value.headers);return s&&M||c.delete(x.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,f.getCacheControlHeader)(p.cacheControl)),await (0,m.sendResponse)(Y,F,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};H?await l(H):await j.withPropagatedContext(e.headers,()=>j.trace(c.BaseServerSpan.handleRequest,{spanName:`${O} ${h}`,kind:a.SpanKind.SERVER,attributes:{"http.method":O,"http.target":e.url}},l))}catch(t){if(t instanceof y.NoFallbackError||await T.onRequestError(e,t,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:z})}),M)throw t;return await (0,m.sendResponse)(Y,F,new Response(null,{status:500})),null}}e.s(["handler",()=>z,"patchFetch",()=>C,"routeModule",()=>T,"serverHooks",()=>E,"workAsyncStorage",()=>R,"workUnitAsyncStorage",()=>N],68781)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__3c4ec3c6._.js.map