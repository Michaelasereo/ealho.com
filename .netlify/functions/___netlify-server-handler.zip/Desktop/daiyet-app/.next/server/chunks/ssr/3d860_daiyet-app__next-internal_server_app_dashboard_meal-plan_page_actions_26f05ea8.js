module.exports=[92511,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_dashboard_meal-plan_page_actions_26f05ea8.js.map