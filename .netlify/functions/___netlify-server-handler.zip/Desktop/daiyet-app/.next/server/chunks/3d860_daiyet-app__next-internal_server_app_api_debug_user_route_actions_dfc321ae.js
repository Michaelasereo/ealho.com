module.exports=[87518,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_debug_user_route_actions_dfc321ae.js.map