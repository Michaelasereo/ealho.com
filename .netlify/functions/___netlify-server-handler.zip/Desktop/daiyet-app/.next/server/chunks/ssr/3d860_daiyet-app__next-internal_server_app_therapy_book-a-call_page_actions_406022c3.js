module.exports=[61116,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_therapy_book-a-call_page_actions_406022c3.js.map