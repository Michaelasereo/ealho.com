module.exports=[33493,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_user_booking-history_route_actions_153635e0.js.map