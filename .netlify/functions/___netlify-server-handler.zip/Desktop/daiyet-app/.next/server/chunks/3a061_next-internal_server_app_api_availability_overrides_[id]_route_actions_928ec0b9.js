module.exports=[61766,(e,o,d)=>{}];

//# sourceMappingURL=3a061_next-internal_server_app_api_availability_overrides_%5Bid%5D_route_actions_928ec0b9.js.map