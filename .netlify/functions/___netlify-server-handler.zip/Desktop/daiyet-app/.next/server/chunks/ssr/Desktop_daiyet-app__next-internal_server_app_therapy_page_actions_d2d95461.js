module.exports=[65089,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_therapy_page_actions_d2d95461.js.map