module.exports=[93070,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_user_approve-request_%5Bid%5D_route_actions_6b86a697.js.map