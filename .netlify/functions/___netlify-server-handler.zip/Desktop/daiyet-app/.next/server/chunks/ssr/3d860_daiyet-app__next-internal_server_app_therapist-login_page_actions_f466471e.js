module.exports=[7875,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_therapist-login_page_actions_f466471e.js.map