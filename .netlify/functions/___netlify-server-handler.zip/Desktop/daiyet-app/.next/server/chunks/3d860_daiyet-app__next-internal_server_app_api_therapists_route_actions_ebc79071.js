module.exports=[5115,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_therapists_route_actions_ebc79071.js.map