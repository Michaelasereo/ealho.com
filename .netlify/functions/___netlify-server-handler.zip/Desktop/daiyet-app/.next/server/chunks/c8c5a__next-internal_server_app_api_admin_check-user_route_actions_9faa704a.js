module.exports=[30206,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_admin_check-user_route_actions_9faa704a.js.map