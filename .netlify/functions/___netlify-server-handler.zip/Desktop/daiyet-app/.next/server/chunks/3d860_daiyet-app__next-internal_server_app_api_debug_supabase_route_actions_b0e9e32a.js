module.exports=[75989,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_debug_supabase_route_actions_b0e9e32a.js.map