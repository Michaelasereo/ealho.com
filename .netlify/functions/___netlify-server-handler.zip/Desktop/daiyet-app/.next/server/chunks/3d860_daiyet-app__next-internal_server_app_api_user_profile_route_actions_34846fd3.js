module.exports=[20989,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_user_profile_route_actions_34846fd3.js.map