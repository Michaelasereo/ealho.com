module.exports=[24792,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_user_upload-profile-image_route_actions_004c0906.js.map