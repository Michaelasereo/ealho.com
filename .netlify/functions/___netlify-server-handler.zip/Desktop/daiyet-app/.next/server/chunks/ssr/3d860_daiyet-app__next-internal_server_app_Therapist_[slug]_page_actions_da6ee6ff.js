module.exports=[7430,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_Therapist_%5Bslug%5D_page_actions_da6ee6ff.js.map