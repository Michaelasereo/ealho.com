module.exports=[36069,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_bookings_page_actions_1403a968.js.map