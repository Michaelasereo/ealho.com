module.exports=[65025,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_Dietitian_%5Bslug%5D_page_actions_9a5b3d23.js.map