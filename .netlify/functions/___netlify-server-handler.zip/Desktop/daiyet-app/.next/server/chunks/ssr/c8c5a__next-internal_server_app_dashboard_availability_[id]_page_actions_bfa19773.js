module.exports=[48720,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_availability_%5Bid%5D_page_actions_bfa19773.js.map