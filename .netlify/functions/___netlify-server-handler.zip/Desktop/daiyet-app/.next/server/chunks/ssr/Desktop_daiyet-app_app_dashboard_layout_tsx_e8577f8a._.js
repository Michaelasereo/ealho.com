module.exports=[9869,a=>{"use strict";var b=a.i(11733);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=Desktop_daiyet-app_app_dashboard_layout_tsx_e8577f8a._.js.map