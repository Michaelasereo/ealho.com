module.exports=[77414,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_meal-plans_page_actions_21a62801.js.map