globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b9a2fe0ec148870e.js",
    "static/chunks/a0d90c357a3dd223.js",
    "static/chunks/3fbb4a4d21a0a17d.js",
    "static/chunks/17c6f31961695e8b.js",
    "static/chunks/71e2f2a307ddc618.js",
    "static/chunks/turbopack-f8f41a012cc39a42.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];