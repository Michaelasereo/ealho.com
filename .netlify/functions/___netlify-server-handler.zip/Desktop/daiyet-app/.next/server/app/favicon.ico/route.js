var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/5f784_next_dist_esm_build_templates_app-route_69b6316c.js")
R.c("server/chunks/Desktop_daiyet-app__next-internal_server_app_favicon_ico_route_actions_4673a0ef.js")
R.m(49829)
module.exports=R.m(49829).exports
