var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__f74a7d71._.js")
R.c("server/chunks/Desktop_daiyet-app_ebd9b570._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/Desktop_daiyet-app__next-internal_server_app_api_bookings_route_actions_87ec0581.js")
R.m(7630)
module.exports=R.m(7630).exports
