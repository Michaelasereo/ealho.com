var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/verify/route.js")
R.c("server/chunks/[root-of-the-server]__d2ac2115._.js")
R.c("server/chunks/Desktop_daiyet-app_ebd9b570._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/3d860_daiyet-app__next-internal_server_app_api_payments_verify_route_actions_5121428f.js")
R.m(94446)
module.exports=R.m(94446).exports
