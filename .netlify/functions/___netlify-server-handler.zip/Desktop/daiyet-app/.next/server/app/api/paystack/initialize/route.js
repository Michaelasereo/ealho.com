var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/paystack/initialize/route.js")
R.c("server/chunks/[root-of-the-server]__c7acdd0c._.js")
R.c("server/chunks/Desktop_daiyet-app_ebd9b570._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/c8c5a__next-internal_server_app_api_paystack_initialize_route_actions_1346a328.js")
R.m(25572)
module.exports=R.m(25572).exports
